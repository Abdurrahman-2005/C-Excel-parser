#include <iostream>
#include <string>
#include <queue>
#include <stack>
#include <fstream>
using namespace std;
struct Node {
    string name, bank, expiryDate;
    long long cardNo;
    int pin;
    Node* next, *prev;
};
struct History {
    public:
        static stack<Node*> stack;
};
stack<Node*> History::stack;
struct Node *head = nullptr;
struct Node *tail = nullptr;
void addNode(string name, string bank, string expiryDate, long long cardNo, int pin) {
    Node* node= new Node;
    node->name = name;
    node->bank = bank;
    node->expiryDate = expiryDate;
    node->cardNo = cardNo;
    node->pin = pin;
    node->prev = nullptr;
    node->next = nullptr;
    if (!head) {head = tail = node; return;}
    node->prev = tail;
    tail->next = node;
    tail = node;
    History::stack.push(node);
}
void print() {
    if (!head) return;
    Node *node = head;
    while (node) {
        cout<<"Card Holder Name: "<<node->name<<", Issuing Bank: "<<node->bank<<", Card Number: "<<node->cardNo<<", Card Expiry Date: "<<node->expiryDate;
        cout<<"\n";
        node=node->next;
    }
}
void print(string user) {
    if (!head) return;
    Node *node = head;
    while (node) {
        if (node->name == user) cout<<"Card Holder Name: "<<node->name<<", Issuing Bank: "<<node->bank<<", Card Number: "<<node->cardNo<<", Card Expiry Date: "<<node->expiryDate;
        node=node->next;
    }
}
void removeUser(long long cardNo, int pin) {
    if (!head) return;
    Node* node = head;
    while (node) {
        if (node->cardNo==cardNo && node->pin == pin) {
            if (head==tail) head = tail = nullptr;
            else if (node==head) {
                head=head->next;
                delete(head->prev);
                head->prev = nullptr;
                cout<<"Deleted";
                return;
            }
            else if (node==tail) {
                tail = tail->prev;
                delete(tail->next);
                tail->next = nullptr;
                cout<<"Deleted";
                return;
            }
            else {
                node->prev->next = node->next;
                node->next->prev = node->prev;
                delete node;
                cout<<"Deleted";
                return;
            }
        }
        node = node->next;
    }
    cout<<"Not Found";
}
Node* getLastUser() {
        if (!head) return nullptr;
        Node* node = History::stack.top();
        History::stack.pop();
        return node;
    }
void removeLastUser() {
    Node* node = History::stack.top();
    node = node->prev;
    delete (node->next);
}
queue<string> splitLine(string& line) {
    queue<string> row;
    int currentIndex = 0;
    while (true) {
        int nextCommaIndex = line.find(',', currentIndex);
        if (nextCommaIndex == -1) {
            row.push(line.substr(currentIndex));
            break;
        }
        string field = line.substr(currentIndex,nextCommaIndex - currentIndex);
        row.push(field);
        currentIndex = nextCommaIndex + 1;
    }
    return row;
}
string getAttribute(queue<string> row, int columnIndex) {
    for (int i=0; i< columnIndex && !row.empty(); i++) row.pop();
    if (!row.empty()) return row.front();
    else return "";
}
queue<queue<string>> parseFile(string fileLocation) {
    ifstream file(fileLocation);
    if(!file) {
        cout<<"File cannot be opened";
        return queue<queue<string>>();
    }
    string line;
    queue<queue<string>> rows;
    getline(file, line);
    while (getline(file, line)) {
        rows.push(splitLine(line));
    }
    return rows;
}
void parseQueueToLinkedList(queue<queue<string>> rows) {
    while (!rows.empty()) {
        queue<string> row = rows.front();
        rows.pop();
            string bank = getAttribute(row, 2);
            long long cardNo = stoll(getAttribute(row, 3));
            string name = getAttribute(row, 4);
            string expiryDate = getAttribute(row, 7);
            int pin = stoi(getAttribute(row, 9));
            addNode(name, bank, expiryDate, cardNo, pin);
        }
}
int main() {
    string fileLocation = "bank.csv";
    queue<queue<string>> rows = parseFile(fileLocation);
    parseQueueToLinkedList(rows);
    int choice = 0;
    do {
        cout << "\n===== Bank Card Management System =====\n";
        cout << "1. Display all users\n";
        cout << "2. Display a specific user by name\n";
        cout << "3. Remove a user by Card Number and PIN\n";
        cout << "4. Display last added user\n";
        cout << "5. Remove last added user\n";
        cout << "6. Add User\n";
        cout << "0. Exit\n";
        cout << "Select an option: ";
        cin >> choice;
        if (choice == 1) {
            print();
        } else if (choice == 2) {
            string username;
            cout << "Enter name of user to search: \n";
            cin>>username;
            print(username);
        } else if (choice == 3) {
            long long cardNo;
            int pin;
            cout << "Enter card number: ";
            cin >> cardNo;
            cout << "Enter PIN: ";
            cin >> pin;
            removeUser(cardNo, pin);
        } else if (choice == 4) {
            Node* node = getLastUser();
            if (node)
                cout << "Last added user: " << node->name << ", Card No: " << node->cardNo << ", Bank: " << node->bank << ", Expiry: " << node->expiryDate <<"\n";
            else
                cout << "No users found.\n";
        } else if (choice == 5) {
            removeLastUser();
            cout << "Last added user removed.\n";
        } else if (choice == 6) {
            cout<<"Enter user details:\n";
            cout<<"Enter name:\n";
            string name; 
            cin>>name;
            cout<<"Enter bank:\n";
            string bank;
            cin>>bank;
            cout<<"Enter card number:\n";
            long long cardNo; 
            cin>>cardNo;
            cout<<"Enter card expiry date:\n";
            string expiryDate; 
            cin>>expiryDate;
            cout<<"Enter card pin:\n";
            int pin; 
            cin>>pin;
            addNode(name, bank, expiryDate, cardNo, pin);
            cout<<"Added successfully";
        } else if (choice != 0) {
            cout << "Invalid choice! Please try again.\n";
        }
    } while (choice != 0);
    return 0;
}